http_path = "/"
css_dir = "/assets/css"
images_dir = "/assets/img"
fonts_dir = "/assets/fonts"
relative_assets = true

# dev
#line_comments = true;

# delivery
line_comments = false;

# prod/demo
#line_comments = false;
#output_style = :compressed;

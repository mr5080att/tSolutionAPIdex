<?php

include 'dbconfig.php';
// connect to the database then edit the row

echo json_encode($_POST);

?>